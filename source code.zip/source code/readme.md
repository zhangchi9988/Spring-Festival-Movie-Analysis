## Running the code
You can use Jupyter Notebook to run .ipynb file.
  - Google Colab is an online service that provides function of Jupyter Notebook, which is suggested to run the code.

To run the code, you may need to upload the data file: `movie data (raw data).csv` first.